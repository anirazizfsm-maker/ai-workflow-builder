import { mutation, query } from "convex/server";
import { v } from "convex/values";

export const getWorkflows = query({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) => {
    return await ctx.db.query("workflows").filter(q => q.eq(q.field("userId"), userId)).collect();
  },
});

export const createWorkflow = mutation({
  args: {
    userId: v.id("users"),
    name: v.string(),
    description: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("workflows", {
      ...args,
      isActive: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      runCount: 0,
    });
  },
});

export const toggleWorkflow = mutation({
  args: { workflowId: v.id("workflows"), active: v.boolean() },
  handler: async (ctx, { workflowId, active }) => {
    await ctx.db.patch(workflowId, { isActive: active });
  },
});
