export async function runAction(ctx, node, inputData) {
  const creds = await ctx.db.get(node.credentialsId);
  const email = inputData?.formData?.email;

  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${creds.data.accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "lethimdo@yourapp.com",
      to: email,
      subject: "Form Received",
      text: "Thanks for submitting the form!",
    }),
  });

  return { sent: true };
}
