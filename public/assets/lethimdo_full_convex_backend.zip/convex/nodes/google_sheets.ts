export async function runAction(ctx, node, inputData) {
  const creds = await ctx.db.get(node.credentialsId);
  const formData = inputData?.formData ?? {};

  const res = await fetch("https://sheets.googleapis.com/v4/spreadsheets/.../values/Sheet1!A1:append", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${creds.data.accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      values: [[formData.name, formData.email]],
    }),
  });

  return await res.json();
}
