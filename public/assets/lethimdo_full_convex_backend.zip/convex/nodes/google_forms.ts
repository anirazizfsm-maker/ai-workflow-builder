export async function runTrigger(ctx, node) {
  // Simulated trigger for now
  return { formData: { name: "John Doe", email: "john@example.com" } };
}
