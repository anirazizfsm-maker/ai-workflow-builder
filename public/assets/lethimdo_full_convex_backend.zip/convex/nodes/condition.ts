export async function runCondition(node, inputData) {
  const { field, equals } = node.config ?? {};
  const value = inputData?.[field];
  return value === equals ? { condition: true } : { condition: false };
}
