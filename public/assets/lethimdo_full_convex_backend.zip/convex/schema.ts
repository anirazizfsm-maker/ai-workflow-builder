import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    email: v.string(),
    name: v.optional(v.string()),
    role: v.optional(v.string()),
  }),
  credentials: defineTable({
    userId: v.id("users"),
    provider: v.string(),
    data: v.any(),
    createdAt: v.number(),
  }),
  workflows: defineTable({
    userId: v.id("users"),
    name: v.string(),
    description: v.optional(v.string()),
    isActive: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.number(),
    runCount: v.optional(v.number()),
  }),
  workflow_nodes: defineTable({
    workflowId: v.id("workflows"),
    type: v.string(),
    label: v.string(),
    position: v.any(),
    config: v.optional(v.any()),
    credentialsId: v.optional(v.id("credentials")),
  }),
  workflow_edges: defineTable({
    workflowId: v.id("workflows"),
    source: v.id("workflow_nodes"),
    target: v.id("workflow_nodes"),
    condition: v.optional(v.string()),
  }),
  workflow_runs: defineTable({
    workflowId: v.id("workflows"),
    userId: v.id("users"),
    status: v.string(),
    logs: v.array(v.string()),
    startedAt: v.number(),
    endedAt: v.optional(v.number()),
  }),
  notifications: defineTable({
    userId: v.id("users"),
    title: v.string(),
    message: v.string(),
    type: v.string(),
    createdAt: v.number(),
    read: v.boolean(),
  }),
  analytics: defineTable({
    workflowId: v.id("workflows"),
    date: v.string(),
    count: v.number(),
  }),
});
