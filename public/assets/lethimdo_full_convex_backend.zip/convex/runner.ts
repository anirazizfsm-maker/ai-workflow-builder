import { mutation } from "convex/server";
import { v } from "convex/values";
import { runTrigger, runAction, runCondition } from "./nodes/_index";

export const startWorkflowRun = mutation({
  args: { workflowId: v.id("workflows"), userId: v.id("users") },
  handler: async (ctx, args) => {
    const workflow = await ctx.db.get(args.workflowId);
    if (!workflow?.isActive) throw new Error("Workflow inactive.");

    const nodes = await ctx.db.query("workflow_nodes").filter(q => q.eq(q.field("workflowId"), args.workflowId)).collect();
    const edges = await ctx.db.query("workflow_edges").filter(q => q.eq(q.field("workflowId"), args.workflowId)).collect();

    const runId = await ctx.db.insert("workflow_runs", {
      workflowId: args.workflowId,
      userId: args.userId,
      status: "running",
      logs: [],
      startedAt: Date.now(),
    });

    const triggerNode = nodes.find(n => n.type === "trigger");
    if (!triggerNode) throw new Error("No trigger node found.");

    await runWorkflow(ctx, { workflow, nodes, edges, triggerNode, runId });

    return runId;
  },
});

export async function runWorkflow(ctx, { workflow, nodes, edges, triggerNode, runId }) {
  const visited = new Set();

  async function executeNext(nodeId, inputData) {
    if (visited.has(nodeId)) return;
    visited.add(nodeId);

    const node = nodes.find(n => n._id.id === nodeId);
    const result = await executeNode(ctx, node, inputData, runId);

    const outgoing = edges.filter(e => e.source.id === nodeId);
    for (const edge of outgoing) {
      await executeNext(edge.target.id, result);
    }
  }

  await executeNext(triggerNode._id.id, {});
  await ctx.db.patch(runId, { status: "success", endedAt: Date.now() });
}

export async function executeNode(ctx, node, inputData, runId) {
  const log = async (msg) => {
    const run = await ctx.db.get(runId);
    const newLogs = [...run.logs, `[${node.label}] ${msg}`];
    await ctx.db.patch(runId, { logs: newLogs });
  };

  try {
    let output = {};
    switch (node.type) {
      case "trigger": output = await runTrigger(ctx, node); break;
      case "action": output = await runAction(ctx, node, inputData); break;
      case "condition": output = await runCondition(node, inputData); break;
      default: throw new Error("Unknown node type");
    }
    await log("✅ Success");
    return output;
  } catch (err) {
    await log(`❌ Error: ${err.message}`);
    await ctx.db.patch(runId, { status: "failed" });
    throw err;
  }
}
