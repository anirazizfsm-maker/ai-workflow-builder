import { mutation } from "convex/server";
import { v } from "convex/values";

export const recordRun = mutation({
  args: { workflowId: v.id("workflows") },
  handler: async (ctx, { workflowId }) => {
    const today = new Date().toISOString().slice(0, 10);
    await ctx.db.insert("analytics", { workflowId, date: today, count: 1 });
  },
});
