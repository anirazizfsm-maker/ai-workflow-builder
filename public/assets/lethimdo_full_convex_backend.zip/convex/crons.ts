import { internalMutation } from "convex/server";
import { startWorkflowRun } from "./runner";

export const hourlyTriggers = internalMutation(async (ctx) => {
  const activeWorkflows = await ctx.db.query("workflows")
    .filter(q => q.eq(q.field("isActive"), true))
    .collect();

  for (const wf of activeWorkflows) {
    const trigger = await ctx.db.query("workflow_nodes")
      .filter(q => q.and(q.eq(q.field("workflowId"), wf._id), q.eq(q.field("type"), "trigger")))
      .first();

    if (trigger?.config?.schedule === "hourly") {
      await startWorkflowRun(ctx, { workflowId: wf._id, userId: wf.userId });
    }
  }
});
